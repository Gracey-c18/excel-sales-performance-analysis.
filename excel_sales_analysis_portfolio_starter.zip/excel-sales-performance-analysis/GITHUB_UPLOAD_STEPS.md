# Publish this project on GitHub

1. Sign in to GitHub and click **New repository**.
2. Name it `excel-sales-performance-analysis`.
3. Use the description: `Excel sales analysis portfolio project demonstrating formulas, KPIs, and dashboard reporting.`
4. Set visibility to **Public** if you're comfortable sharing the project.
5. Create the repository. If prompted, do not create another README because this folder already contains one.
6. Upload `README.md`, `sales_analysis.xlsx`, and `sales_data.csv` using **Add file → Upload files**.
7. Commit the files with the message: `Add Excel sales analysis portfolio project`.
8. Open the repository page and check that the README displays clearly and both data files are downloadable.

Tip: Later, add a screenshot of the Excel dashboard to the README so recruiters can see the result without downloading the workbook.
