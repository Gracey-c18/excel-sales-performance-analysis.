# Excel Sales Performance Analysis

## Business question
How is the business performing across regions, sales channels, and product categories, and where should managers investigate opportunities to improve revenue and profit?

## Project overview
This portfolio project uses a **synthetic 2025 sales dataset** to demonstrate practical Excel skills for a junior Business Analyst role.

### Excel skills demonstrated
- Structured data table and frozen headers
- Calculated columns using formulas
- Revenue, total cost, profit, and profit margin
- KPI summary dashboard
- `SUMIF`, `SUM`, `COUNTA`, `AVERAGE`, and `IFERROR`
- Charts comparing revenue by region and category
- Clear separation between raw data and dashboard

## Files
- `sales_analysis.xlsx` — workbook with source data, calculated fields, KPI dashboard, and charts
- `sales_data.csv` — raw synthetic dataset for reuse

## How to use
1. Download `sales_analysis.xlsx` and open it in Microsoft Excel or a compatible spreadsheet app.
2. Review the `Sales_Data` sheet and inspect the formulas in columns K:N.
3. Open `Dashboard` to review KPIs and revenue charts.
4. Try adding a PivotTable using the `SalesTable` data to compare revenue and profit by region, category, and sales channel.

## Important note
All records are fictional and generated for portfolio practice. This is not real company data. Currency is shown in dollars as a neutral example.

## Suggested business analysis questions
1. Which region generates the highest revenue?
2. Which product category contributes the most revenue?
3. How do revenue and profit differ by sales channel?
4. Which products have high revenue but lower profit margins?
5. What additional data would you request before recommending a change?

## Next improvement
Add a PivotTable analysis, document 3–5 evidence-based findings, and include recommendations with measurable business impact.
